from collections import Counter
import nltk
import pandas as pd
from nltk.corpus import gutenberg
import matplotlib.pyplot as plt
from operator import itemgetter
import numpy as np
from scipy.optimize import curve_fit

# Load the text and preprocess it
text1 = gutenberg.raw('C://Users//Twister//PycharmProjects//Complext_System1//Lives_of_the_apostles.txt')  # Text in Language 1
text2 = gutenberg.raw('C://Users//Twister//PycharmProjects//Complext_System1//Don_Quijote.txt')  # Text in Language 2
texts = [text1, text2]

for lang_idx, item in enumerate(texts, start=1):
    row_list = []
    word_freq = Counter(item.split())
    print(f"Word Frequencies for Language {lang_idx}:")
    print(word_freq)

    rank = 0
    words = {}
    for word in item.split():
        words[word] = words.get(word, 0) + 1

    top_words = sorted(words.items(), key=itemgetter(1), reverse=True)[:]
    for word, frequency in top_words:
        rank += 1
        row = {'Language': f'Language{lang_idx}', 'Word': word, 'Rank': rank, 'Frequency': frequency}
        row_list.append(row)

    # Create DataFrame for each language
    df = pd.DataFrame(row_list, columns=['Language', 'Word', 'Rank', 'Frequency'])

    # Plotting for each language
    plt.figure(figsize=(12, 8))

    # Calculate Zipf-Mandelbrot distribution parameters
    a, b = 1.0, 0.0  # You may adjust these parameters

    # Calculate empirical distribution
    rank = df['Rank']
    empirical_frequency = df['Frequency'] / len(df)

    # Plot empirical distribution
    plt.loglog(rank, empirical_frequency, marker='o', linestyle='-', label=f'Empirical - Language{lang_idx}')

    # Fit the Zipf-Mandelbrot distribution parameters using curve_fit
    params, covariance = curve_fit(lambda rank, a, b: 1 / ((rank + b) ** a), rank, empirical_frequency, p0=[a, b])

    # Calculate and plot theoretical Zipf-Mandelbrot distribution using fitted parameters
    theoretical_frequency = 1 / ((rank + params[1]) ** params[0])
    plt.loglog(rank, theoretical_frequency, linestyle='--', label=f'Theoretical (Zipf-Mandelbrot) - Language{lang_idx}')

    # Display fitted parameters
    print(f'Language{lang_idx} - Fitted parameters (a, b): {params}')

    plt.xlabel('Rank (r)')
    plt.ylabel('Frequency (F)')
    plt.title(f'Empirical vs Theoretical Zipf-Mandelbrot Distribution (Log-Log Scale) - Language{lang_idx}')
    plt.legend()
    plt.show()
