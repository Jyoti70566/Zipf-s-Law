from collections import Counter
import nltk
import pandas as pd
from nltk.corpus import gutenberg
import matplotlib.pyplot as plt
from operator import itemgetter
import numpy as np
from scipy.stats import zipf
from scipy.optimize import curve_fit

# Load the text and preprocess it
text1 = gutenberg.raw('C://Users//Twister//PycharmProjects//Complext_System1//Lives_of_the_apostles.txt')
text2 = gutenberg.raw('C://Users//Twister//PycharmProjects//Complext_System1//A_system_of_practical_medicine.txt')
text3 = gutenberg.raw('C://Users//Twister//PycharmProjects//Complext_System1//The_Count_of_Monte_Cristo.txt')
text4 = gutenberg.raw('C://Users//Twister//PycharmProjects//Complext_System1//Don_Quijote.txt')
texts = [text1, text2, text3, text4]

for idx, item in enumerate(texts, start=1):
    row_list = []
    word_freq = Counter(item.split())
    print(f"Word Frequencies for Text {idx}:")
    print(word_freq)

    rank = 0
    words = {}
    for word in item.split():
        words[word] = words.get(word, 0) + 1

    top_words = sorted(words.items(), key=itemgetter(1), reverse=True)[:]
    for word, frequency in top_words:
        rank += 1
        row = {'Text': f'Text{idx}', 'Word': word, 'Rank': rank, 'Frequency': frequency}
        row_list.append(row)

    # Create DataFrame for each text
    df = pd.DataFrame(row_list, columns=['Text', 'Word', 'Rank', 'Frequency'])

    # Plotting for each text
    plt.figure(figsize=(10, 6))

    for idx, text_df in df.groupby('Text'):
        total_words = len(text_df)
        normalized_frequency = text_df['Frequency'] / total_words
        plt.plot(text_df['Rank'], normalized_frequency, marker='*', linestyle='-', label=idx)

    plt.xlabel('Rank (r)')
    plt.ylabel('Normalized Frequency')
    plt.title(f'Normalized Word Frequencies - Text{idx}')
    plt.legend()
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    plt.show()
    plt.figure(figsize=(10, 6))
    plt.loglog(df['Frequency'], df['Rank'], label=f'Text{idx}')
    plt.xlabel('Rank (r)', fontsize=14, fontweight='bold')
    plt.ylabel('Frequency (F)', fontsize=14, fontweight='bold')
    plt.legend()
    plt.title(f'Word Frequencies for Text {idx}')
    plt.show()
    # Plotting for each text
    plt.figure(figsize=(12, 8))

    # Calculate Zipf distribution parameters
    s = 1.0  # You may adjust this parameter

    # Calculate empirical distribution
    rank = df['Rank']

    empirical_frequency = df['Frequency'] / len(df)

    # Plot empirical distribution
    plt.loglog(rank, empirical_frequency, marker='o', linestyle='-', label=f'Empirical - Text{idx}')


    # Define the theoretical Zipf distribution function
    def zipf_distribution(rank, s):
        return 1 / (rank ** s)


    # Fit the Zipf distribution parameters using curve_fit
    params, covariance = curve_fit(zipf_distribution, rank, empirical_frequency, p0=[s])

    # Calculate and plot theoretical Zipf distribution using fitted parameters
    theoretical_frequency = zipf_distribution(rank, *params)
    plt.loglog(rank, theoretical_frequency, linestyle='--', label=f'Theoretical (Zipf) - Text{idx}')

    # Display fitted parameters
    print(f'Text{idx} - Fitted parameter (s): {params[0]}')

    plt.xlabel('Rank (r)')
    plt.ylabel('Frequency (F)')
    plt.title(f'Empirical vs Theoretical Zipf Distribution (Log-Log Scale) - Text{idx}')
    plt.legend()
    plt.show()
